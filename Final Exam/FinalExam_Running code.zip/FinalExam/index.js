//Took the index code reference from Halloween week 13 b
// import dependencies you will use
const express = require('express');
const path = require('path');
const { convert } = require('html-to-text');
//const bodyParser = require('body-parser'); // not required for Express 4.16 onwards as bodyParser is now included with Express
// set up expess validator
const {check, validationResult} = require('express-validator'); //destructuring an object
const fileupload = require('express-fileupload');

// steps for adding login/logout
const session = require('express-session');
// steps to save data to DB 
// 1. Install mongoose
// 2. Fetch mongoose into your project
const mongoose = require('mongoose');
// 3. Connect to DB
mongoose.connect('mongodb://127.0.0.1:27017/FinalExamOrderStore');
// 4. Create a model
const Card = mongoose.model('Card', {
    
    email: String,
    client : String,            
    
    PlateQuantity:Number,
    SlippersQuantity:Number,
    JacketsQuantity:Number,
    
    subTotal:Number,
    gst:Number,
    total:Number
    
});
// create a model for admin users
const AdminUsers = mongoose.model('AdminUsers',{
    UserName: String,
    Password: String
});
var clientRegex = /^[A-Z]{3}-\d{3}$/;
// set up variables to use packages
var myApp = express();
// myApp.use(bodyParser.urlencoded({extended:false})); // old way before Express 4.16
myApp.use(express.urlencoded({extended:false})); // new way after Express 4.16
myApp.use(fileupload());

myApp.use(session({
    secret: 'aslkdfjlaskd1237103498', // should be unique for each application
    resave: false,
    saveUninitialized: true
})); 

// set path to public folders and view folders

myApp.set('views', path.join(__dirname, 'views'));
//use public folder for CSS etc.
myApp.use(express.static(__dirname+'/public'));
myApp.set('view engine', 'ejs');
// home page
myApp.get('/',function(req, res){
    res.render('AddOrder'); // render form.ejs file from the views folder
});
// custom function to write a custom validation for lunch
// this function needs to accept a value and and object
function customProductValidation(value, {req}){
    //var lunch = value;
    var PlateQuantity=req.body.Plate;
    var SlippersQuantity=req.body.Slippers;
    var JacketsQuantity=req.body.Jackets;
    var client = req.body.clientNum;
    if(isNaN(PlateQuantity)||isNaN(SlippersQuantity)||isNaN(JacketsQuantity))
    {
        throw new Error('Please enter valid quantity');
    }
    else if(!clientRegex.test(client))
    {
        throw new Error('Please enter valid client number');
    }
    
    else
    {
        return true; // if no errors in validation
    }
    
    
}
myApp.post('/process', [
    
    check('Email', 'Please enter an email').isEmail(),
    
    check('client','client number not in correct format'),
    check('PlateQuantity').custom(customProductValidation)

], function(req,res){
    console.log(req.body);

    //fetch data
    
    var email = req.body.Email;
    var PlateQuantity=req.body.Plate;
    var SlippersQuantity=req.body.Slippers;
    var JacketsQuantity=req.body.Jackets;
    var client = req.body.clientNum;

    const errors = validationResult(req);
    if(!errors.isEmpty())
    { // if there are errors
        //res.send('There are errors');
        var errorData = errors.array();
        var userData = {
            
            email: email,
            client : client
            
            
        }
        var pageData = {
            errors: errorData,
            userData: userData
        }
        //console.log(errorData);
        res.render('AddOrder', pageData);
    }
    else{ // if there are no errors
        //process data
        var subTotal=0;
        var x='',z='';
        var y=0;
        var gst=0;
        
        
        
        
        
        
        var tax=0.13;
        

          
          subTotal=(PlateQuantity)*17.5+(SlippersQuantity)*12.99+(JacketsQuantity*41.99);//calculates sub total  
        gst=(subTotal*tax);
        var total=subTotal+gst;
        
        
        
        var userData = {
            
            email: email,
            client : client,            
            
            PlateQuantity:PlateQuantity,
            SlippersQuantity:SlippersQuantity,
            JacketsQuantity:JacketsQuantity,
            
            subTotal:subTotal,
            gst:gst,
            total:total

        }
        var pageData = {
            
            userData: userData
        }
        var myCard = new Card(userData);
        // 6. Save the object
        myCard.save();
        
        res.render('process', pageData);
    }
});
// render the login form
myApp.get('/login',function(req, res){
    res.render('login'); // will render views/login.ejs
});
myApp.get('/logout',function(req, res){
    req.session.UserName = ''; // reset the UserName
    req.session.loggedIn = false; // make logged in false from true
    res.redirect('/login');
});

//show all the cards in a table
myApp.get('/list',function(req, res){

    if(req.session.loggedIn){ // check if the user is logged in, you can also expand this functionality to check for user type such as admin or manager.
        // show them the list
        Card.find({}).exec(function(err, cards){
            var pageData = {
                cards: cards
            }
            res.render('list', pageData);
        });
    }
    else{
        // redirect to the login page
        res.redirect('/login');
    }
});
// login process page

myApp.post('/loginprocess', function(req, res){
    // fetch input
    var UserName = ((req.body.UserName).trim()).toString();
    var Password = ((req.body.Password).trim()).toString();
    
    // find in database 
    AdminUsers.findOne({UserName: UserName, Password: Password}).exec(function(err, adminuser){
        console.log(UserName,Password);
        console.log(adminuser);
        console.log(err);
        if(adminuser){ // would be true if there is data returned in adminuser
            // save in session
            req.session.UserName = adminuser.UserName;
            req.session.loggedIn = true;
            //res.send('You logged in'); // change this later
            res.redirect('/list');
        }
        else{
            //res.send('UserName and pass not correct'); // change this later
            var pageData = {
                error : 'Login details not correct'
            }
            res.render('login', pageData);
        }
    });
});
// unique card
myApp.get('/delete/:id',function(req, res){

    if(req.session.loggedIn){
        var id = req.params.id;
        //res.send('the id is ' + id);
    
        Card.findByIdAndDelete({_id:id}).exec(function(err, card){

            var message = 'Sorry, order not found'; // be default assume card not found
            if(card){ // if card exists, then change the message
                message = 'Order deleted successfully';
            }

            var pageData = {
                message: message
            }
            res.render('delete', pageData);
        });
    }
    else{
        res.redirect('/login');
    }

});
//listen at a port
myApp.listen(8081);
console.log('Open http://localhost:8081 in your browser');