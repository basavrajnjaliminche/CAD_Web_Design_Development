
// import dependencies 
const express = require("express");
const path = require("path");
const mongoose = require("mongoose");

//express session
const session = require("express-session");
const fileUpload = require("express-fileupload");


//MongoDB

mongoose.connect('mongodb://127.0.0.1:27017/blogstore', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});
console.log("basu");

//Models
const Admin = mongoose.model("admin", {
    username: String,
    password: String,
});

const Blog = mongoose.model("Blog", {
    title: String,
    imageName: String,
    desc: String,
    path: String,
});

/****************************Variables****************************/
var myApp = express();
myApp.use(express.urlencoded({ extended: false }));


myApp.use(
    session({
        secret: "63927b743e12f327673439a2", 
        resave: false,
        saveUninitialized: true,
    })
);

//parse application json
myApp.use(express.json());
// set path to public 
myApp.set("views", path.join(__dirname, "views"));

myApp.use(express.static(__dirname + "/public"));
myApp.set("view engine", "ejs");
myApp.use(fileUpload());



//home page
myApp.get("/", function (req, res) {
    res.redirect("/login");
});
//show all the cards in a table
myApp.get('/list',function(req, res){

    if(req.session.userLoggedIn){ 
        Blog.find({}).exec(function(err, Blogs){
            var pageData = {
                Blogs: Blogs
            }
            res.render('appPosts', pageData);
        });
    }
    else{
        // redirect to the login page
        res.redirect('/login');
    }
});
//Login Page
// this function renders a login page
myApp.get("/login", function (req, res) {
    console.log("Rendering Logging Page");
    res.render("login", { userLoggedIn: req.session.userLoggedIn });
});

// Login post handler

myApp.post("/login", function (req, res) {
    var user = req.body.username;
    var pass = req.body.password; 
    
    console.log(user+" ---------------"+pass);

    Admin.find({username:user,password:pass}).exec(function 
        (err,
         admin
         ) {
        // log any errors
        console.log(admin+" ---------------");

        if (admin) {
            //store username in session and set logged in true
            req.session.username = admin.username;
            req.session.userLoggedIn = true;
            // redirect to the dashboard
            res.redirect("/controller");
        } else {
            res.render("login", { error: "Sorry, cannot login!" });
        }
    });
});


myApp.get("/view/:id", function (req, res) {
    var blogid = req.params.id;
    console.log(blogid);
    Blog.findOne({ _id: blogid }).exec(function (err, blog) {
        console.log(blog);
        if (blog) {
            res.render("view", {
                blog: blog
                
            });
        } else {
            console.log("error");
        }
    });
});

// adds a new blog to the MongoDB blogs 
myApp.post("/addBlog", function (req, res) {
    //fetch all the form fields
    var title = req.body.title; 
    var desc = req.body.desc;

    // get name of file
    var imageName = req.files.imageName.name;
    // get the actual file (temporary file)
    var imageNameFile = req.files.imageName;
    
    var imageNamePath = "public/blogs/" + imageName;
    // move temp file 
    imageNameFile.mv(imageNamePath, function (err) {
        console.log("error", err);
    });

    // create object  fetched data  send to  view
    var blogDetails = {
        title: title,
        desc: desc,
        imageName: imageName,
        path: `/blogs/${title}`,
    };

    // save data to database
    var myBlog = new Blog(blogDetails); 
    myBlog.save().then(() => console.log("New Blog Created"));

    // send the data to result view and render it
    res.render("addNewBlog", { status: "success", imageName: imageName });
});



myApp.get("/controller", function (req, res) {
    // check if the user is logged in
    if (req.session.userLoggedIn) {
        console.log("Is user Logged in ", req.session.userLoggedIn);
        res.render("controller");
    } else {
        // otherwise send the user to the login page
        res.redirect("/login");
    }
});

// function renders the add page feature.
myApp.get("/addNewBlog", function (req, res) {
    // check if the user is logged in
    if (req.session.userLoggedIn) {
        res.render("addNewBlog", { status: "", imageName: "" });
    } else {
        // otherwise send user to  login page
        res.redirect("/login");
    }
});


 
myApp.get("/edit", function (req, res) {
    // check if the user is logged in
    if (req.session.userLoggedIn) {
        var allBlogs;
        var customBlogs = [];
        Blog.find({}).exec(function (err, blogs) {
            allBlogs = [...blogs];
            allBlogs.forEach(function (element) {
                var tempObject = { ...element._doc };
                tempObject.deleteLink = "/delete/" + tempObject.title;
                tempObject.editLink = "/edit/" + tempObject.title;
                customBlogs.push(tempObject);
            });

            res.render("editBlogs", { blogs: customBlogs });
        });
    } else {
        res.redirect("/login");
    }
});

e
myApp.get("/edit/:blogId", function (req, res) {
    // check if the user is logged in
    if (req.session.userLoggedIn) {
        var blogId = req.params.blogId;
        Blog.findOne({ title: blogId }).exec(function (err, blog) {
            if (blog) {
                res.render("editBlog", {
                    blog: blog, 
                    status: ""
                });
            } else {
                console.log("error");
            }
        });
    } else {
        res.redirect("/login");
    }
});


myApp.post(
    "/edit/editBlog",
    function (req, res) {
       
        var title = req.body.title; 
        var desc = req.body.desc;
    
      
        var imageName = req.files.imageName.name;
       
        var imageNameFile = req.files.imageName;
       
        var imageNamePath = "public/blogs/" + imageName;
       
        imageNameFile.mv(imageNamePath, function (err) {
            console.log("error", err);
        });
    
        
        var editedBlog = {
            desc: desc,
            imageName: imageName,
        };
    
        Blog.findOneAndUpdate({title: title}, editedBlog).exec((err, doc)=> console.log("Document Updated Succesfully"));
        res.render("editBlog", {status: "success"})
    }
);

//Delete page

myApp.get("/delete/:blogTitle", function (req, res) {
    // check if the user is logged in
    if (req.session.userLoggedIn) {
        var blogTitle = req.params.blogTitle;
        Blog.findOneAndDelete({ title: blogTitle }).exec(function (err, blog) {
            if (blog) {
                res.render("deleteBlog", {
                    message: "Successfully deleted!",
                });
            } else {
                res.render("deleteBlog", {
                    message: "Sorry, could not delete!",
                });
            }
        });
    } else {
        res.redirect("/login");
    }
});


// this function renders the author page.
myApp.get("/author", function (req, res) {
    res.render("author", {
        name: "Basavraj Jaliminche",
        studentNumber: "800149",
        userLoggedIn: req.session.userLoggedIn,
    });
});


//Logout Page
myApp.get("/logout", function (req, res) {
    //Remove variables from session
    req.session.username = "";
    req.session.userLoggedIn = false;
    res.render("login", { error: "Logged Out" });
});

// start the server and listen at a port
myApp.listen(8080);

//tell everything was ok
console.log("Everything executed fine.. website at port 8080...");
myApp.listen(3000);
console.log("Everything executed, open http://localhost:3000/ in the browser.");
