
var person = {
    name: "Basu",
    phone: "5197815728",
    email: "basu@gmail.com",
    team: "a5"
}


var {name, phone, email} = person;

console.log(name);